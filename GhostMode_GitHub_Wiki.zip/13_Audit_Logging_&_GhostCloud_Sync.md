# Audit Logging & GhostCloud Sync

12. GUI & Admin Dashboard

Tools:
- `ghostcontrol.py`: main control panel
- `admin_dashboard.py`: user management (view/reset/lock/unlock)
- `admin_dashboard_gui_secure.py`: PyQt5 GUI variant
- `identity_switcher_gui.py`: tray-based identity selector