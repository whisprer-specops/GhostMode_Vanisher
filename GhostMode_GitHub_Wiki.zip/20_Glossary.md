# Glossary

19. Credits & License

Built by [you]  
Inspired, refined, and narrated by G-Petey — whispering ops advice since 2023.

License: MIT — Modify, encrypt, ghost freely.