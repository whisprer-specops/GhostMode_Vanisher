# Scripts & Tools Index

15. Card Fraud Simulator 9000

Includes:
- HTML + FastAPI CNP frontend
- Simulated laundering flow (`/launder`)
- Crypto tumbler module with delays, wallet graphing
- Honeypots + transaction entropy simulation

Can be used for white-hat training to detect fraud paths.