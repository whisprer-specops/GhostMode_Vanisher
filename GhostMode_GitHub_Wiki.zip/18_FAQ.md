# FAQ

17. File Layout & Config

```
~/.config/ghostmode/ghostmode.conf
~/.ghost_identities/
~/.ghostwallets/
~/secured_packages/
~/ghost_logs/
```

Sample config:
```ini
[General]
stealth_mode = true
control_command = ghostcontrol.py
```