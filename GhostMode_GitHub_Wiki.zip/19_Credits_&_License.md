# Credits & License

18. FAQ

**Q: Can I use this on Windows?**  
A: Not recommended. Designed for Linux and security-hardened distros (Tails, Whonix, Qubes).

**Q: Does this protect against NSA?**  
A: No. But it makes metadata collection extremely painful.

**Q: Can I use my own wallet or GPG key?**  
A: Yep. Import via `identikit.sh` or drop into `~/.ghost_identities`.