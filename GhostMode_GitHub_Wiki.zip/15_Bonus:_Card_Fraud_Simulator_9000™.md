# Bonus: Card Fraud Simulator 9000™

14. Tamper Detection & Honeypots

Includes:
- Encrypted `.sig` tamper detection (salted HMAC)
- Stego-based unlock password delivery (image hidden)
- Honeypot wallets (in Fraud Simulator)
- Unlock logs show trigger source, IP, time
- Detection disables unlock if forged attempt