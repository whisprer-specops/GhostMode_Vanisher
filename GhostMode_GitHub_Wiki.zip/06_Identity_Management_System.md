# Identity Management System

5. Daily Usage Guide

Run `ghost_systray.py` or launch from your app menu.

Tray features include:
- Cold sign/export `.txn`
- Hot decrypt + broadcast `.txn.gpg`
- Launch Control Panel (GUI)
- Open Identity Switcher
- Trigger GhostDrop self-wipe